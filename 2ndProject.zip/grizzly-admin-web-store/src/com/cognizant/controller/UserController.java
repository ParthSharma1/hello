package com.cognizant.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Product;
import com.cognizant.entity.User;
import com.cognizant.service.ProductService;
import com.cognizant.service.UserService;

@Controller
public class UserController {
	
	public UserController(){
		System.out.println("********User Controller*********");
	}
	
	@Autowired
	private Validator validator;
	@Autowired
	private UserService userservice;
	
	@Autowired
	private ProductService productservice;
	

	@RequestMapping(value="LoginUser.htm",method=RequestMethod.GET)
	public ModelAndView doLogin(@RequestParam("uname") String UserName,@RequestParam("pname") String PassWord ){
		boolean userLogin=userservice.checkUser(UserName,PassWord);
		System.out.println("-in do login--");
		ModelAndView mv=new ModelAndView();
		//mv.addObject("productList",productList);
		if(userLogin==true) {
			List<Product> productList=productservice.getAllProducts();
			mv.addObject("productList",productList);
			mv.setViewName("viewproducts");
			

		
		}
		else {
			
			mv.setViewName("login");
		
		}
		return mv;
	}
	@ModelAttribute("user")
	public User createUserCommandObject(){
		User user=new User();
		user.setUserName("UserName");
		user.setPassWord("Your Password");
		
		return user;
	}
	@ModelAttribute("product")
	public Product createProductCommandObject(){
		Product product=new Product();
		product.setProductId(0);
		product.setProductName("Your name please");
		product.setProductDescription("productDescription");
		product.setProductPrice(0.0);
		return product;
	}
	
	@RequestMapping(value="index.htm",method=RequestMethod.GET)
	public ModelAndView loadForm(){
		System.out.println("--in load form--");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("login");
		return mv;
	}
	
	@RequestMapping(value="addproduct.htm",method=RequestMethod.POST)
	public ModelAndView persistProduct(@ModelAttribute("product")Product product,Errors errors){
		ModelAndView mv=new ModelAndView();
		ValidationUtils.invokeValidator(validator, product, errors);
		if(errors.hasErrors()){
			mv.setViewName("productform");
		}else{
			
		boolean productPersist=productservice.persistProduct(product);
		
		if(productPersist){
			mv.addObject("status", "Product successfully Registered");
			List<Product> productList=productservice.getAllProducts();
			
			mv.addObject("productList",productList);
			mv.setViewName("viewproducts");
		
		}
		else
		{
			mv.addObject("status", "Fail Fail");
			mv.setViewName("productform");

		}
		
		}
		return mv;
		
	}
	@RequestMapping(value="LogoutUser.htm",method=RequestMethod.GET)
	public ModelAndView logoutUser(HttpSession session){
		ModelAndView mv=new ModelAndView();
		System.out.println("---Logout---");
		session.invalidate();
		mv.setViewName("login");
		return mv;
		}
	@RequestMapping(value="viewProduct.htm",method=RequestMethod.GET)
	public ModelAndView viewProducts(){
		List<Product> productList=productservice.getAllProducts();
		ModelAndView mv=new ModelAndView();
		mv.addObject("productList",productList);
		mv.setViewName("viewproducts");
		return mv;
		
	}
	
	@RequestMapping(value="deleteproduct.htm",method=RequestMethod.GET)
	public ModelAndView deleteProduct(@RequestParam("productId") String productId){
		System.out.println(productId);
		int pID=Integer.parseInt(productId);
		boolean res=productservice.deleteProduct(pID);
		ModelAndView mv=new ModelAndView();
		
		List<Product> productList=productservice.getAllProducts();
		
		mv.addObject("productList",productList);
		mv.setViewName("viewproducts");
		return mv;
		
	}
	
	@RequestMapping(value="productForm.htm",method=RequestMethod.GET)
	public String loadProductForm(){
		return "productform";
	}
	@ModelAttribute("categoryList")
	public List<String> createProductCategory(){
		return productservice.getProductCategoryNames();
	}
	
}
