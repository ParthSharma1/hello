package com.cognizant.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Product;

@Repository("ProductDAOImpl")
public class ProductDAOImpl implements ProductDAO{

	@Autowired
	SessionFactory sessionFactory;
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		List<Product> productList=session.createQuery("from Product").list();
		session.close();
		return productList;
	}

	@Override
	public List<String> getCategoriesNames() {
			Session session=sessionFactory.openSession();
			Query query=session.createSQLQuery("select category_name from product_categories");
			List<String> categoryList=query.list();

		return categoryList;
	}

	@Override
	public boolean insertProduct(Product product) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.persist(product);
		tx.commit();
		session.close();
		
		return true;
	}

	@Override
	public int checkProduct(Product product) {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Product o where o.productId=:productId or o.productCategory=:productCategory");
		query.setInteger("productId",product.getProductId());
		query.setString("productCategory",product.getProductCategory());
		int productExists=0;
		List<Product> productList=query.list();
		for(Product productDB:productList){
			if(productDB.getProductId()==product.getProductId()){
				productExists=1;
			}else if(productDB.getProductCategory().equals(product.getProductCategory())){
				productExists=2;
			}
			else if(productDB.getProductId()==product.getProductId() && productDB.getProductCategory().equals(product.getProductCategory())){
				productExists=3;
			}
		}
		
		session.close();
		
		
		return productExists;
	}

	

	@Override
	public boolean deleteProduct(int pID) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Query query = session.createQuery("delete from Product where Product_Id = :pID ");
		query.setParameter("pID", pID);
		tx.commit();
		sessionFactory.close();
		return true;
	}

	@Override
	public List<Product> viewProduct(int pID) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Query query = session.createQuery(" from Product where Product_Id = :pID ");
		query.setParameter("pID", pID);
		List<Product> List=query.list();
		tx.commit();
		sessionFactory.close();
		return List;
	}

	

}
