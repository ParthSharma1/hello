package com.cognizant.Dao;

public interface UserDAO {
	
	boolean checkUser(String User,String Pass);

}
