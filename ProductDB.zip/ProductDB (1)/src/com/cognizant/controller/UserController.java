package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Product;
import com.cognizant.entity.User;
import com.cognizant.service.ProductService;
import com.cognizant.service.UserService;

@Controller
public class UserController {
	
	
	@Autowired
	private UserService userservice;
	@Autowired
	private
	ProductController productController;
	@RequestMapping(value="LoginUser.htm",method=RequestMethod.GET)
	public ModelAndView viewProducts(@RequestParam("uname") String Username,@RequestParam("pname") String Password ){
		boolean userLogin=userservice.checkUser(Username,Password);
		ModelAndView mv=new ModelAndView();
		//mv.addObject("productList",productList);
		if(userLogin==true) {
		return productController.viewProducts();
		
		}
		else {
			mv.setViewName("index");
			return mv;
		}
		
	}
	@ModelAttribute("user")
	public User createCommandObject(){
		User user=new User();
		user.setUserName("UserName");
		user.setPassWord("Your Password");
		
		return user;
	}
	

	
}
